package com.booke;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBookStoreEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookStoreEcommerceApplication.class, args);
	}

}
