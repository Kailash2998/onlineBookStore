package com.booke.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.booke.model.Book;
import com.booke.model.Category;
import com.booke.model.User;
import com.booke.repository.BookRepository;
import com.booke.repository.UserRepository;
import com.booke.service.AuthorService;
import com.booke.service.BookService;
import com.booke.service.CategoryService;
import com.booke.service.UserService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private BookService bookService;

	@Autowired
	CategoryService categoryService;

	@Autowired
	BookRepository bookRepository;

	@Autowired
	AuthorService authorService;

	@ModelAttribute
	public void commonUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			User user = userRepository.findByEmail(email);
			m.addAttribute("user", user);
		}
	}

	@GetMapping("/profile")
	public String customer(Model model, @RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "2") int size) {
		Page<Book> books = bookService.getAllBooks(PageRequest.of(page, size));
		model.addAttribute("categories", categoryService.getAllCategory());
		model.addAttribute("authors", authorService.getAllAuthor());
		model.addAttribute("books", books);
		return "user";
	}

	
	@GetMapping("/profile/category/{id}")
	public String shopByCategory(Model model, @PathVariable int id) {
		model.addAttribute("categories", categoryService.getAllCategory());
		model.addAttribute("books", bookService.getAllBookByCategoryId(id));
		return "user";
	}
	
	@GetMapping("/profile/search")
	public String searchBooks(@RequestParam("keyword") String keyword, Model model) {
		List<Book> books = bookService.searchBooks(keyword);
		model.addAttribute("books", books);
		return "search-results"; // Return the view name
	}
}