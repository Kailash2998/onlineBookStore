package com.booke.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.hibernate.query.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.booke.dto.BookDTO;
import com.booke.model.Author;
import com.booke.model.Book;
import com.booke.model.Category;
import com.booke.model.OrderStatus;
import com.booke.model.PlaceOrder;
import com.booke.repository.BookRepository;
import com.booke.repository.CategoryRepository;
import com.booke.repository.OrderRepository;
import com.booke.service.AuthorService;
import com.booke.service.BookService;
import com.booke.service.CategoryService;
import com.booke.service.OrderService;

@Controller
public class AdminControlller {

	@Autowired
	CategoryService categoryService;

	@Autowired
	BookService bookService;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	AuthorService authorService;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	OrderService orderService;

	private int PAGE_SIZE;

	@GetMapping("/admin-page/categories")
	public String showCategories(Model model, @RequestParam(defaultValue = "0") int page) {
		Page<Category> categoryPage = categoryService.findAll(PageRequest.of(page, 4));
		model.addAttribute("categories", categoryPage.getContent());
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", categoryPage.getTotalPages());
		return "categories";
	}

	@GetMapping("/admin-page/categories/add")
	public String getCatAdd(Model model) {
		model.addAttribute("category", new Category());
		return "categoriesAdd";
	}

	@PostMapping("/admin-page/categories/add")
	public String postCatAdd(@ModelAttribute("category") Category category) {
		categoryService.addCategory(category);
		return "redirect:/admin-page/categories";
	}

	@GetMapping("/admin-page/categories/delete/{id}")
	public String deleteCat(@PathVariable int id) {
		categoryService.removeCategoryById(id);
		return "redirect:/admin/categories";
	}

	@GetMapping("/admin-page/categories/update/{id}")
	public String updateCat(@PathVariable int id, Model model) {
		Optional<Category> category = categoryService.getCategoryById(id);
		if (category.isPresent()) {
			model.addAttribute("category", category.get());
			return "categoriesAdd";
		} else {
			return "404";
		}
	}
	
//	@PostMapping("/admin-page/categories/search")
//    public String searchCategories(@RequestParam String keyword, Model model) {
//        List<Category> searchResults = categoryService.searchCategories(keyword);
//        model.addAttribute("categories", searchResults);
//        return "search-category";
//    }

	// author Section

	@GetMapping("/admin-page/authors")
	public String getAuthorsPage(Model model, @RequestParam(defaultValue = "0") int page) {
		int pageSize = 3; // You can adjust this according to your preference
		Page<Author> authorPage = authorService.getAllAuthors(PageRequest.of(page, pageSize));
		model.addAttribute("authors", authorPage.getContent());
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", authorPage.getTotalPages());
		return "authors";
	}

	@GetMapping("/admin-page/authors/add")
	public String getAddAuthor(Model model) {
		model.addAttribute("author", new Author());
		return "authorAdd";
	}

	@PostMapping("/admin-page/authors/add")
	public String postAddAuthor(@ModelAttribute("author") Author author) {
		authorService.addAuthor(author);
		return "redirect:/admin-page/authors";
	}

	@GetMapping("/admin-page/authors/delete/{id}")
	public String deleteAuthor(@PathVariable int id) {
		authorService.removeAuthorById(id);
		return "redirect:/admin/authors";
	}

	@GetMapping("/admin-page/authors/update/{id}")
	public String updateAuthor(@PathVariable int id, Model model) {
		Optional<Author> author = authorService.getAuthorById(id);
		if (author.isPresent()) {
			model.addAttribute("author", author.get());
			return "authorAdd";
		} else {
			return "404";
		}
	}

	@GetMapping("/admin-page/books")
	public String books(Model model, @RequestParam(defaultValue = "0") int page) {
		int pageSize = 2; // You can adjust this value as per your requirement
		Pageable pageable = PageRequest.of(page, pageSize);
		Page<Book> bookPage = bookService.getAllBooks(pageable);
		model.addAttribute("books", bookPage.getContent());
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", bookPage.getTotalPages());

		return "books";
	}

	@GetMapping("/admin-page/books/add")
	public String productAddGet(Model model) {
		model.addAttribute("bookDTO", new BookDTO());
		model.addAttribute("categories", categoryService.getAllCategory());
		model.addAttribute("authors", authorService.getAllAuthor());
		return "booksAdd";
	}

	private static String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/bookImages";

	@PostMapping("/admin-page/books/add")
	public String productAddPost(@ModelAttribute("bookDTO") BookDTO bookDTO,
			@RequestParam("bookImage") MultipartFile file, @RequestParam("imgName") String imgName) throws IOException {

		Book book = new Book();
		book.setBookId(bookDTO.getBookId());
		book.setName(bookDTO.getName());
		book.setAuthor(authorService.getAuthorById(bookDTO.getAuthorId()).get());
		book.setCategory(categoryService.getCategoryById(bookDTO.getCategoryId()).get());
		book.setPrice(bookDTO.getPrice());
		book.setWeight(bookDTO.getWeight());
		book.setQuantity(bookDTO.getQuantity());
		book.setIsbn(bookDTO.getIsbn());
		book.setDescription(bookDTO.getDescription());
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();
			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());

		} else {
			imageUUID = imgName;

		}
		book.setImageName(imageUUID);
		bookService.addBook(book);
		return "redirect:/admin-page/books";
	}

	@GetMapping("/admin-page/books/delete/{id}")
	public String deleteBook(@PathVariable long id) {
		bookService.removeBookById(id);
		return "redirect:/admin-page/books";
	}

	@GetMapping("/admin-page/books/update/{id}")
	public String updateBookGet(@PathVariable long id, Model model) {
		Book book = bookService.getBookById(id).get();
		BookDTO bookDTO = new BookDTO();
		bookDTO.setBookId(book.getBookId());
		bookDTO.setName(book.getName());
		bookDTO.setIsbn(book.getIsbn());
		bookDTO.setAuthorId(book.getAuthor().getId());
		bookDTO.setCategoryId(book.getCategory().getId());
		bookDTO.setPrice(book.getPrice());
		bookDTO.setQuantity(book.getQuantity());
		bookDTO.setWeight(book.getWeight());
		bookDTO.setDescription(book.getDescription());
		bookDTO.setImageName(book.getImageName());

		model.addAttribute("categories", categoryService.getAllCategory());
		model.addAttribute("authors", authorService.getAllAuthor());
		model.addAttribute("bookDTO", bookDTO);

		return "booksAdd";
	}

	// order section

	@GetMapping("/admin-page/updateOrderStatus")
	public String showOrderList(Model model, @RequestParam(defaultValue = "0") int page) {
		Page<PlaceOrder> pagedOrders = orderService.getOrders(PageRequest.of(page, 3)); // Change 10 to the desired page
																						// size

		model.addAttribute("pagedOrders", pagedOrders);
		model.addAttribute("currentPage", pagedOrders.getNumber());
		model.addAttribute("totalPages", pagedOrders.getTotalPages());
		model.addAttribute("orderCount", pagedOrders.getTotalElements());

		return "ordersList";
	}

	@PostMapping("/admin-page/updateOrderStatus")
	public String updateOrderStatus(@RequestParam("orderId") Long orderId, @RequestParam("status") String status) {
		Optional<PlaceOrder> optionalOrder = orderRepository.findById(orderId);
		if (optionalOrder.isPresent()) {
			PlaceOrder order = optionalOrder.get();
			String uppercaseStatus = status.toUpperCase();
			switch (uppercaseStatus) {
			case "CANCELLED":
				order.setOrderStatus(OrderStatus.CANCELLED);
				break;
			case "CONFIRMED":
				order.setOrderStatus(OrderStatus.CONFIRMED);
				break;
			default:
				return "redirect:/admin-page/updateOrderStatus";
			}
			orderRepository.save(order);
		} else {
		}
		return "redirect:/admin-page/updateOrderStatus";
	}

	@GetMapping("/admin-page/canceledOrders")
	public String showAllOrders(Model model) {
		List<PlaceOrder> allOrders = orderRepository.findAll();
		List<PlaceOrder> canceledOrders = orderRepository.findByOrderStatus(OrderStatus.CANCELLED);
		List<PlaceOrder> confirmedOrders = orderRepository.findByOrderStatus(OrderStatus.CONFIRMED);

		model.addAttribute("allOrders", allOrders);
		model.addAttribute("canceledOrders", canceledOrders);
		model.addAttribute("confirmedOrders", confirmedOrders);

		return "canceledOrdersList";
	}

//	@GetMapping("/admin-page/orderhistory")
//	public String showOrderHistory(Model model) {
//	    List<PlaceOrder> orderHistory = orderService.getAllOrders(); 
//	    model.addAttribute("orderHistory", orderHistory);
//	    return "orderHistory";
//	}

	

	@GetMapping("/admin-page/orderhistory")
	public String showOrderHistory(Model model, @RequestParam(defaultValue = "0") int page) {
	    try {	        Page<PlaceOrder> pagedOrders = orderService.getOrders(PageRequest.of(page, 5));
	        
	        model.addAttribute("pagedOrders", pagedOrders);
	        model.addAttribute("currentPage", page);
	        model.addAttribute("totalPages", pagedOrders.getTotalPages());
	        
	        return "orderHistory";
	    } catch (Exception e) {
//	        logger.error("Error occurred while fetching order history: {}", e.getMessage());
	        // Redirect to an error page or show a generic error message
	        return "error"; // Update to the appropriate error page or message
	    }
	}


}
