package com.booke.model;

public enum PaymentOption {
    FULL_PAYMENT,
    PARTIAL_PAYMENT,
    INSTALLMENT_PAYMENT
}
