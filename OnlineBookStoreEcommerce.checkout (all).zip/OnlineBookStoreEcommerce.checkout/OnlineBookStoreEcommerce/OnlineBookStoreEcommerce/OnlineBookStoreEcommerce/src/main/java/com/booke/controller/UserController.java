package com.booke.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.booke.dto.UserDto;
import com.booke.global.GlobalData;
import com.booke.model.Book;
import com.booke.model.User;
import com.booke.service.BookService;
import com.booke.service.UserService;

import jakarta.validation.Valid;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {

	@Autowired
	UserDetailsService userDetailsService;

	@Autowired
	UserService userService;

	@Autowired
	BookService bookService;

	@GetMapping("/")
	public String homePage() {
		return "home";
	}

	@GetMapping("/detail.html")
	public String detailPage() {
		return "detail";
	}

	@GetMapping("/listing.html")
	public String listPage() {
		return "listing";
	}

	@GetMapping("/registration")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User()); // Assuming User is your form backing object
		return "register";
	}

	@PostMapping("/registration")
	public String saveUser(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			return "register";
		}
		userService.save(user);
		model.addAttribute("message", "Registered Successfully");
		return "redirect:/login";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/admin-page")
	public String adminPage() {
		return "admin";
	}

}
