package com.booke.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
	CustomUserDetailsService customUserDetailsService;

	@Bean
	public CustomSucessHandler customSucessHandler() {
		return new CustomSucessHandler();
	}

	@Bean
	public static PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http.csrf(c -> c.disable()).authorizeHttpRequests(request -> request
////					.requestMatchers("/", "/shop/**", "/register", "/**").permitAll()
//				.requestMatchers("/**").permitAll().requestMatchers("/admin-page/**").hasAuthority("ADMIN")
//				.requestMatchers("/user-page/**").hasAuthority("USER")
////				.requestMatchers("/**").permitAll()
//				.anyRequest().authenticated())
//				.formLogin(form -> form.loginPage("/login").loginProcessingUrl("/login")
//						.successHandler(customSucessHandler()).permitAll())
//				.logout(form -> form.invalidateHttpSession(true).clearAuthentication(true)
//						.logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login?logout")
//						.permitAll());
//
//		return http.build();
//	}

	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	    http
	        .csrf().disable() 
	        .authorizeHttpRequests(authorize -> authorize
	            .requestMatchers("/admin-page/**").hasAuthority("ADMIN")
	            .requestMatchers("/customer/profile/**").hasAuthority("USER")
	            .requestMatchers("/cart/**", "/checkout/**").authenticated() 
	            .requestMatchers("/**").permitAll() 
	            .anyRequest().authenticated() 
	        )
	        .formLogin(form -> form
	            .loginPage("/login")
	            .loginProcessingUrl("/login")
	            .successHandler(customSucessHandler())
	            .permitAll()
	        )
	        .logout(logout -> logout
	            .invalidateHttpSession(true)
	            .clearAuthentication(true)
	            .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
	            .logoutSuccessUrl("/login?logout")
	            .permitAll()
	        );

	    return http.build();
	}

//	 public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//		  http.csrf().disable().authorizeHttpRequests().requestMatchers("/customer/**").hasRole("CUSTOMER")
//		    .requestMatchers("/seller/**").hasRole("SELLER").requestMatchers("/admin/**").hasRole("ADMIN")
//		    .requestMatchers("/cart/**").authenticated().requestMatchers("/checkout/**").authenticated()
//		    .requestMatchers("/add-to-cart").authenticated().requestMatchers("/**").permitAll().and().formLogin()
//		    .loginPage("/login").loginProcessingUrl("/userLogin").successHandler(sucessHandler).permitAll();
//		  return http.build();
//		 }
	
	
//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http.csrf(c -> c.disable()).authorizeHttpRequests(request -> request
////					.requestMatchers("/", "/shop/**", "/register", "/**").permitAll()
//				.requestMatchers("/**").permitAll().requestMatchers("/admin-page/**").hasRole("ADMIN")
//				.requestMatchers("/user-page/**").hasAuthority("USER")
//				.requestMatchers("/cart/**").authenticated().requestMatchers("/checkout/**").authenticated()
//				
////				.requestMatchers("/**").permitAll()
//				.anyRequest().authenticated())
//				.formLogin(form -> form.loginPage("/login").loginProcessingUrl("/login")
//						.successHandler(customSucessHandler()).permitAll())
//				.logout(form -> form.invalidateHttpSession(true).clearAuthentication(true)
//						.logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login?logout")
//						.permitAll());
//
//		return http.build();
//	}

	
	@Autowired
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(customUserDetailsService).passwordEncoder(passwordEncoder());
	}
}
