package com.booke.service;

import java.util.Optional;

import com.booke.dto.UserDto;
import com.booke.model.User;

public interface UserService {

	User save(User user);

	User findByEmail(String name);

	User getUserByUsername(String username);

	User findByUsername(String username);
}
