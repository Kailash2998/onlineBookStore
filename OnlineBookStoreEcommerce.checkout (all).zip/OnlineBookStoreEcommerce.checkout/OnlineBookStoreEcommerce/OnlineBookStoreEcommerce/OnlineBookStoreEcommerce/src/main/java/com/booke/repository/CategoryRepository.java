package com.booke.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.booke.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer> {

	List<Category> findAll();
	
//	 Page<Category> findAll(Pageable pageable);
	 Page<Category> findAll(Pageable pageable);

	List<Category> findByNameContainingIgnoreCase(String keyword);
	 List<Category> findByNameContaining(String keyword);

}
