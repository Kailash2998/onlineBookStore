package com.booke.model;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
    
    
}
